package jkyeiasare;

public class ManagmentCompany {
	final private int MAX_PROPERTY = 5;
	private double mgmFeePer;
	private String name;
	private Property[] properties = new Property[ MAX_PROPERTY];
	private String taxID;
	final private int MGMT_WIDTH = 10;
	final private int MGMT_DEPTH = 10;
	private Plot plot;
	public ManagmentCompany(String name, String taxID, double mgmFee, int x, int y, int width, int depth) {
		ManagmentCompany p = new ManagmentCompany(this.name, this.taxID, mgmFee, x, y, width, depth);
	}
	public ManagmentCompany(ManagmentCompany otherCompany ) {
		ManagmentCompany j = otherCompany;
	}
	public ManagmentCompany(String name, String taxID, double mgmFee) {
		ManagmentCompany z = new ManagmentCompany(this.name, this.taxID,mgmFee);
	}
	public ManagmentCompany() {
		ManagmentCompany a = new ManagmentCompany();
	}
	
	public int addProperty(Property p) {
			int val = 0;
			properties[0] = p;
			if(properties[0] != p) {
				val = -1;
			}
			if(properties[0] == null) {
				val = -2;
			}
			if(properties[0] == properties[5]) {
				val = -3;
			}
			if((properties[0].plot.encompasses(plot) != true) || (properties[0].plot.overlaps(plot) != true) ) {
				val = -4;
			}
			return val;
			
	}
	public int addProperty(String propertyName, String city, String ownerName, Plot plot, double rent, int x, int y, int width, int depth){
		Property newProp = new Property(propertyName, city, ownerName, rent,  plot, x,  y, width, depth);
		properties[1] = newProp;
		int val = 0;
		properties[0] = newProp;
		if(properties[0] != newProp) {
			val = -1;
		}
		if(properties[0] == null) {
			val = -2;
		}
		if(properties[0] == properties[5]) {
			val = -3;
		}
		if((properties[0].plot.encompasses(plot) != true) || (properties[0].plot.overlaps(plot) != true) ) {
			val = -4;
		}
		return val;
		
	}
	public int addProperty(String propertyName, String city, double rent, String ownerName, Plot plot) {
		Property newP = new Property(propertyName, city, ownerName, rent, plot);
		properties[2] = newP;
		int val = 0;
		properties[0] = newP;
		if(properties[0] != newP) {
			val = -1;
		}
		if(properties[0] == null) {
			val = -2;
		}
		if(properties[0] == properties[5]) {
			val = -3;
		}
		if((properties[0].plot.encompasses(plot) != true) || (properties[0].plot.overlaps(plot) != true) ) {
			val = -4;
		}
		return val;
	}
	public double totalRent() {
		double sum = 0;
		for(int i = 0; i< properties.length; i++) {
			sum = sum + properties[0].getRentAmount();
		}
		return sum;
	}
	public String maxRentProp() {
		String x = "";
		double max = properties[0].getRentAmount();
		for(int i = 1; i< properties.length; i++) { 
			if(properties[i].getRentAmount()> max) {
				x =properties[i].toString();
			}
		}
		return x;
	}
	
	int maxRentPropIndex() {
		int x = 0;
		double max = properties[0].getRentAmount();
		for(int i = 1; i< properties.length; i++) { 
			if(properties[i].getRentAmount()> max) {
				x = i;
			}
		}
		return x;
	}
	
	String displayPropertyAtIndex( int i) {
		String y = properties[i].toString();
		return y;
	}
	public Object getMAX_PROPERTY() {
		// TODO Auto-generated method stub
		return null;
	}
	
}

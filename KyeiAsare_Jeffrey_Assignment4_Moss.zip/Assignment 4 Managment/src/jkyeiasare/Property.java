package jkyeiasare;

public class Property {
	String city;
	String owner;
	String propertyName;
	double rentAmount;
	Plot plot;
	private int x;
	private int y;
	private int width;
	private int depth;
	
	public Property() {
		city = "";
		owner = "";
		propertyName = "";
		rentAmount = 0;
		plot = null;
	}
	
	public Property(Property p) {
		Property j = new Property ();
		j = p;
	}
	
	public Property(String propertyName, String city, String owner, double rentAmount, Plot plot) {
		this.propertyName = propertyName;
		this.city = city;
		this.owner = owner;
		this.rentAmount = rentAmount;
		x = 0;
		y = 0;
		width = 1;
		depth = 1;
	}
	
	public Property(String propertyName, String city, String owner, double rentAmount, Plot plot, int x, int y, int width, int depth) {
		this.propertyName = propertyName;
		this.city = city;
		this.owner = owner;
		this.rentAmount = rentAmount;
		this.x = x;
		this.y = y;
		this.width = width;
		this.depth = depth;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getPropertyName() {
		return propertyName;
	}
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	public double getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}
	public void setPlot(Plot plot) {
		this.plot = plot;
	}
	public String toString() {
		return "Property Name:" + propertyName +
		"Located in" + city +
		"Belonging to:" + owner +
		"Rent Amount:" + rentAmount;
		
	}
}

package jkyeiasare;

public class Plot {
	private int x;
	private int y;
	private int width;
	private int depth;
	
	public Plot() {
		x = 0;
		y = 0;
		width = 1;
		depth = 1;
	}
	
	public Plot(Plot p) {
		Plot j = new Plot ();
		j = p;
	}

	
	public Plot(int x, int y, int width, int depth) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.depth = depth;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getDepth() {
		return depth;
	}
	public void setDepth(int depth) {
		this.depth = depth;
	}
	public void set(Plot plot) {
		this.depth = depth;
	}
	public String toString() {
		return "Upper left: " + "(" + x + "," + y + ");" 
				+ "Width: " + width + "Depth: " + depth;	
	}
	public boolean encompasses(Plot plot) {
		
		boolean val1 = false; //Check if x encompassed
		boolean val2 = false; //Check if y encompassed
		
		int newRightX = plot.getX() + plot.getWidth();
		int newLeftX = plot.getX();
		int newTopY = plot.getY();
		int newBottomY = plot.getY() - plot.getDepth();
		int newDepth = plot.getDepth();
		int newWidth = plot.getWidth();    //Get new X, Y, Depth, and Width
		
		int rightX = x + width;
		int leftX = x;
		int topY = y;
		int bottomY = y - depth;
		int depthOG = depth;
		int widthOG = width;    //Get og X, Y, Depth, and Width
		
		if(((leftX < newRightX) && (newRightX < rightX)) && 
				((leftX < newLeftX) && (newLeftX < rightX))
				&& (newWidth < widthOG)){   //X encompass
			val1 = true;
		}
		if(((bottomY < newBottomY) && (newBottomY < topY)) && 
				((bottomY < newTopY) && (newTopY < topY))
				&& (newDepth < depthOG)){ //Y encompass
			val2 = true;
		}
		return (val1 && val2); //x and y encompass
		
		
	}
	public boolean overlaps(Plot plot) {
		int newLeftX = plot.getX();
		int newTopY = plot.getY();
		int newBottomY = plot.getY() - plot.getDepth();
		int newRightX = plot.getX() + plot.getWidth();
		
		int rightX = x + width;
		int leftX = x;
		int topY = y;
		int bottomY = y - depth;
		boolean val = true;
		
		if((newLeftX == leftX) || (newTopY == topY) || (newRightX == rightX) || (newBottomY == bottomY)){
			val = false;
		}
		if((newLeftX >= rightX) || (leftX >= newRightX)) {
			val = false;
		}
		if((newBottomY >= topY) || (bottomY >= newTopY) ) {
			val = false;
		}
		return val;
	}
}
